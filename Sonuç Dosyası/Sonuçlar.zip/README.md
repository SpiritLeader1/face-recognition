Bu dosya ExpressionPoints excelleri için açıklama içindir.
- Satır boyunca dizilen duygular yüzlerin durumunu, sütun boyunca dizilen duygular arka plandaki ilişkili duyguyu temsil etmektedir.
- Her bir hücredeki dizi sırasıyla (intact sayısı, rearranged sayısı, new sayısı) olarak belirlenmiştir.